u must use dt 
dont use hide shot