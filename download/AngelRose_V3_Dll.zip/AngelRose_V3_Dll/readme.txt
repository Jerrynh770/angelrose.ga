cfg loc : C:\AngelRose.ga
